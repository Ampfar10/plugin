const axios = require("axios");

const userScores = {}; // Stores user scores

module.exports = {
    name: "riddle",
    description: "Get a random riddle and try to guess the answer!",
    async execute(ctx, commandsByCategory, args) {  
        try {
            const bot = ctx.bot;
            if (!bot) throw new Error("Bot instance is undefined!");

            // Fetch a random riddle from the public API
            const response = await axios.get("https://riddles-api.vercel.app/random");
            const riddle = response.data;

            if (!riddle || !riddle.riddle || !riddle.answer) {
                return await ctx.reply("❌ Failed to get a riddle. Try again later!");
            }

            // Store user score if not already tracked
            const userId = ctx.senderId;
            if (!userScores[userId]) userScores[userId] = 0;

            // Hint system - reveal half the answer if user types "hint"
            const hint = riddle.answer.substring(0, Math.ceil(riddle.answer.length / 2)) + "...";

            // Send the riddle to the user
            await ctx.reply(`🧩 *RIDDLE*: ${riddle.riddle}\n\n⏳ You have *30 seconds* to answer!\n\n💡 Type *hint* to get a clue!`);

            let answered = false; // Track if the user answered in time

            // Filter function to check messages from the same chat
            const filter = (message) => message.chatId === ctx.chatId;

            // Message event listener
            const messageHandler = async (message) => {
                if (!filter(message)) return;

                const userAnswer = message.text.toLowerCase().trim();
                const correctAnswer = riddle.answer.toLowerCase().trim();

                if (userAnswer === "hint") {
                    await ctx.reply(`💡 Hint: *${hint}*`);
                    return;
                }

                answered = true; // User has answered

                if (userAnswer === correctAnswer) {
                    userScores[userId] += 1; // Increase user score
                    await ctx.reply(`✅ Correct! 🎉 You now have *${userScores[userId]}* points!`);
                } else {
                    await ctx.reply(`❌ Wrong! The correct answer was: *${riddle.answer}*`);
                }

                // Remove event listener after one response
                bot.ev.off("message", messageHandler);
            };

            bot.ev.on("message", messageHandler);

            // Set a time limit (30 seconds)
            setTimeout(async () => {
                if (!answered) {
                    await ctx.reply(`⏳ Time's up! The correct answer was: *${riddle.answer}*`);
                    bot.ev.off("message", messageHandler);
                }
            }, 30000); // 30 seconds

        } catch (error) {
            console.error("Error fetching riddle:", error);
            await ctx.reply("❌ An error occurred while fetching the riddle.");
        }
    },
};
