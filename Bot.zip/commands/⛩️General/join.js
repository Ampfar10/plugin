module.exports = {
    name: "join",
    description: "Join a group using the provided invite link.",
    async execute(ctx, commandsByCategory, args, bot) {
        // Log args for debugging
        console.log("Received args:", args);

        // Check if args is valid
        if (!args || !Array.isArray(args) || args.length === 0) {
            return await ctx.reply("❌ Please provide a valid WhatsApp group invite link.");
        }

        // Join the args into a single string
        const inviteLink = args.join("").trim();
        if (!inviteLink) {
            return await ctx.reply("❌ Please provide a valid WhatsApp group invite link.");
        }

        // Validate the invite link
        const inviteRegex = /https:\/\/chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
        const match = inviteLink.match(inviteRegex);
        if (!match || match.length < 2) {
            return await ctx.reply("❌ The provided link is not a valid WhatsApp group invite link.");
        }

        try {
            const groupInviteCode = match[1]; // Extract the invite code from the link

            // Attempt to join the group
            const groupInfo = await bot.acceptInvite(groupInviteCode);

            // Respond with success message
            await ctx.reply(`✅ Successfully joined *${groupInfo.subject}*`);
        } catch (error) {
            console.error("Error joining group:", error);
            await ctx.reply("❌ Failed to join the group. Please check the link or try again later.");
        }
    },
};
