module.exports = {
    name: "bc",  // Command name is 'bc'
    description: "Send a message to all groups the bot is in.",
    async execute(ctx, commandsByCategory, args, bot) {
        console.log("Received args:", args);

        // If args is empty or undefined, check ctx.body directly
        if (!args || args.length === 0) {
            // Try to capture the message text after the command name
            const messageText = ctx.body ? ctx.body.split(" ").slice(1).join(" ").trim() : "";

            if (!messageText) {
                return await ctx.reply("❌ Please provide a message to broadcast.");
            }
            args = [messageText];  // Update args if message is extracted
        }

        // Join the args into a single string for the broadcast message
        const broadcastMessage = args.join(" ").trim();
        if (!broadcastMessage) {
            return await ctx.reply("❌ Please provide a valid message to broadcast.");
        }

        try {
            // Get all chats the bot is part of
            const chats = await bot.getChats();
            const groupChats = chats.filter((chat) => chat.isGroup);

            if (groupChats.length === 0) {
                return await ctx.reply("⚠️ The bot is not in any groups to broadcast the message.");
            }

            // Broadcast the message to all groups
            let successCount = 0;
            for (const group of groupChats) {
                try {
                    await bot.sendMessage(group.id, {
                        text: `📢 *Broadcast Message:*\n\n${broadcastMessage}`,
                    });
                    successCount++;
                } catch (error) {
                    console.error(`Failed to send message to group: ${group.name}`, error);
                }
            }

            // Confirmation reply
            await ctx.reply(`✅ Broadcast sent to ${successCount} group(s).`);
        } catch (error) {
            console.error("Error executing broadcast command:", error);
            await ctx.reply("❌ An error occurred while broadcasting the message. Please try again.");
        }
    },
};
