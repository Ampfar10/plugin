module.exports = {
    name: "help",
    description: "Lists all available commands categorized by functionality.",
    async execute(ctx, commandsByCategory) {
        const tym = new Date();
        const hour = tym.getHours();
        const senderName = ctx.senderName || "User";
        let greeting;

        // Determine greeting based on the time of day
        if (hour >= 0 && hour < 12) {
            greeting = `Good Morning ${ctx.senderName}`;
        } else if (hour >= 12 && hour < 18) {
            greeting = `Good Afternoon ${ctx.senderName}`;
        } else {
            greeting = `Good Evening ${ctx.senderName}`;
        }

        let response = `${greeting}\n*🤖 Here are the bot commands 🤖*\n\n`;
        for (const category in commandsByCategory) {
            response += `*${category}*:\n`;
            commandsByCategory[category].forEach((command) => {
                response += `*${command.name}*,`;
            });
            response += "\n\n";
        }
        await ctx.reply(response);
    },
};
