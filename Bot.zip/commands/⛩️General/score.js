module.exports = {
    name: "score",
    description: "Check your current riddle game score.",
    async execute(ctx) {
        const userId = ctx.senderId;
        const score = userScores[userId] || 0;
        await ctx.reply(`🏆 Your current score: *${score}* points!`);
    },
};
