module.exports = {
    name: "ping",
    description: "Responds with Pong!",
    async execute(ctx) {
        await ctx.reply("Pong! Bot is online.");
    },
};
