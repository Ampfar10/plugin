const admin = require("firebase-admin");

// Initialize Firebase
const serviceAccount = require("../../william-b3a2b-firebase-adminsdk-u5y2f-ee37853315.json");
if (!admin.apps.length) {
    admin.initializeApp({
        credential: admin.credential.cert(serviceAccount)
    });
}
const db = admin.firestore();

module.exports = {
    name: "t2coll",
    aliases: ["t2coll"],
    category: "Card game",
    async execute(ctx) {
        const userId = ctx._sender?.jid;
        if (!userId) return ctx.reply("🟥 *User not found.*");

        const args = ctx.args;
        if (!args || args.length === 0 || isNaN(args[0])) {
            return ctx.reply("🟥 *Please specify a valid card number from your deck.*");
        }

        const cardIndex = parseInt(args[0]) - 1;

        try {
            const userRef = db.collection("users").doc(userId);
            const userDoc = await userRef.get();

            if (!userDoc.exists) return ctx.reply("🟥 *User not found.*");

            const userData = userDoc.data();
            let deck = userData.deck || [];
            let claimedCards = userData.claimedCards || [];

            if (cardIndex < 0 || cardIndex >= deck.length) {
                return ctx.reply("🟥 *Invalid card number.*");
            }

            // Move the selected card from deck back to claimedCards
            const selectedCard = deck.splice(cardIndex, 1)[0];
            claimedCards.push(selectedCard);

            // Save back to Firestore
            await userRef.update({ deck, claimedCards });

            await ctx.reply(`✅ *${selectedCard.title} has been moved back to your collection!*`);
        } catch (error) {
            console.error("Error moving card back to collection:", error);
            await ctx.reply("🟥 *An error occurred while moving the card back to your collection.*");
        }
    }
};
