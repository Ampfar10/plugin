const fs = require("fs");
const path = require("path");


const sellcardsDir = path.join(__dirname, "../../sellcards");

// Admins who can end any sale
const allowedAdmins = ["27672633675@s.whatsapp.net", "27678113720@s.whatsapp.net"];

module.exports = {
    name: "endsale",
    async execute(ctx) {
        const userId = ctx.sender.jid; // Get user ID
        const groupId = ctx.id; // Get group ID
        if (!groupId) return ctx.reply("🟥 *Group ID not found.*");

        try {
            const groupFilePath = path.join(sellcardsDir, `${groupId}.json`);
            if (!fs.existsSync(groupFilePath)) return ctx.reply("🟥 *No active sale in this group.*");

            const saleData = JSON.parse(fs.readFileSync(groupFilePath, "utf-8"));

            // Check if the user is the seller or an allowed admin
            if (saleData.sellerId !== userId && !allowedAdmins.includes(userId)) {
                return ctx.reply("🟥 *Only the seller or an admin can end this sale.*");
            }

            // Delete sale file
            fs.unlinkSync(groupFilePath);

            // Notify group that the sale has ended
            if (saleData.url) {
                await ctx.reply({
                    image: { url: saleData.url },
                    caption: `⛔ *Sale Ended!* ⛔\n🃏 *Card*: ${saleData.title}\n💎 *Tier*: ${saleData.tier}`
                });
            } else {
                await ctx.reply("⛔ *Sale has been ended!*");
            }

        } catch (error) {
            console.error("Error ending sale:", error);
            await ctx.reply("🟥 *An error occurred while ending the sale.*");
        }
    },
};
