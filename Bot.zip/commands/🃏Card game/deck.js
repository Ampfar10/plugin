const admin = require("firebase-admin");
const Jimp = require("jimp");
const fs = require("fs");
const path = require("path");

// Initialize Firebase
const serviceAccount = require("../../william-b3a2b-firebase-adminsdk-u5y2f-ee37853315.json");
if (!admin.apps.length) {
    admin.initializeApp({
        credential: admin.credential.cert(serviceAccount)
    });
}
const db = admin.firestore();

module.exports = {
    name: "deck",
    async execute(ctx) {
        const userId = ctx._sender?.jid;
        if (!userId) return ctx.reply("🟥 *User not found.*");

        try {
            const userDoc = await db.collection("users").doc(userId).get();
            if (!userDoc.exists) return ctx.reply("🟥 *User not found.*");

            const userData = userDoc.data();
            const deck = userData.deck || [];

            if (deck.length === 0) return ctx.reply("🟥 *Your deck is empty.*");

            // Format deck list message
            let deckList = "🃏 *Your Deck:*\n\n";
            deck.forEach((card, index) => {
                deckList += `*#${index + 1} ${card.title}*\n\n`;
            });

            // Ensure the downloads directory exists
            const downloadsDir = path.join(__dirname, "../../downloads");
            if (!fs.existsSync(downloadsDir)) {
                fs.mkdirSync(downloadsDir);
            }

            // Load all images from URLs
            const images = await Promise.all(
                deck.map(async (card) => {
                    try {
                        return await Jimp.read(card.url);
                    } catch (error) {
                        console.error(`Error loading image for ${card.title}:`, error);
                        return null; // Handle invalid images gracefully
                    }
                })
            );

            // Remove failed images
            const validImages = images.filter(img => img !== null);
            if (validImages.length === 0) {
                return ctx.reply("🟥 *Failed to load deck images.*");
            }

            // Set dimensions (assumes all cards are the same size)
            const cardWidth = validImages[0].bitmap.width;
            const cardHeight = validImages[0].bitmap.height;
            const padding = 10;

            // Grid layout (max 3 per row)
            const cols = Math.min(validImages.length, 3);
            const rows = Math.ceil(validImages.length / cols);
            const totalWidth = cols * (cardWidth + padding) - padding;
            const totalHeight = rows * (cardHeight + padding) - padding;

            // Create blank canvas
            const combinedImage = new Jimp(totalWidth, totalHeight, 0x00000000);

            // Place each card in the grid
            validImages.forEach((img, index) => {
                const x = (index % cols) * (cardWidth + padding);
                const y = Math.floor(index / cols) * (cardHeight + padding);
                combinedImage.composite(img, x, y);
            });

            // Save the final merged image
            const outputFilePath = path.join(downloadsDir, "deck_output.jpg");
            await combinedImage.writeAsync(outputFilePath);

            // Send the deck with the combined image
            await ctx.reply({
                image: { url: outputFilePath }, 
                caption: deckList
            });

        } catch (error) {
            console.error("Error generating deck image:", error);
            await ctx.reply("🟥 *An error occurred while retrieving your deck.*");
        }
    }
};
