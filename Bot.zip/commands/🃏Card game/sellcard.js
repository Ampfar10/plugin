const admin = require("firebase-admin");
const fs = require("fs");
const path = require("path");

// Initialize Firebase
const serviceAccount = require("../../william-b3a2b-firebase-adminsdk-u5y2f-ee37853315.json");
if (!admin.apps.length) {
    admin.initializeApp({
        credential: admin.credential.cert(serviceAccount)
    });
}
const db = admin.firestore();

const sellcardsDir = path.join(__dirname, "../../sellcards");

module.exports = {
    name: "sellcard",
    async execute(ctx) {
        const userId = ctx._sender?.jid;
        const groupId = ctx.id;

        if (!userId || !groupId) {
            return ctx.reply("🟥 *User or group not found.*");
        }

        // Parsing the card index and price from the command
        const args = ctx.args;
        if (args.length < 2) {
            return ctx.reply("🟥 *Please specify the card index and the price (e.g., sellcard 1 2000).*");
        }

        const cardIndex = parseInt(args[0]) - 1; // Convert index to 0-based
        const price = parseInt(args[1]);

        if (isNaN(cardIndex) || cardIndex < 0 || cardIndex > 5) {
            return ctx.reply("🟥 *Invalid card index. Please choose between 1 and 6.*");
        }

        if (isNaN(price) || price <= 0) {
            return ctx.reply("🟥 *Invalid price. Please provide a valid positive price.*");
        }

        try {
            const userDoc = await db.collection("users").doc(userId).get();
            if (!userDoc.exists) {
                return ctx.reply("🟥 *User not found.*");
            }

            const userData = userDoc.data();
            const deck = userData.deck || [];

            if (deck.length === 0 || !deck[cardIndex]) {
                return ctx.reply("🟥 *You don't have this card in your deck.*");
            }

            const cardToSell = deck[cardIndex];
            const cardTitle = cardToSell.title;

            // Check if there's already a sale in the group
            const groupFilePath = path.join(sellcardsDir, `${groupId}.json`);
            if (fs.existsSync(groupFilePath)) {
                return ctx.reply("🟥 *There is already a card on sale in this group. Please wait for it to expire or be purchased.*");
            }

            // Store the sale details in a JSON file specific to the group
            const saleDetails = {
                sellerId: userId,
                title: cardTitle,
                price: price,
                cardDetails: cardToSell,
                timestamp: Date.now(),
                saleActive: true // NEW: Sale active flag
            };

            fs.writeFileSync(groupFilePath, JSON.stringify(saleDetails, null, 2));

            // Set a timeout to return the card after 5 minutes if not bought
            setTimeout(async () => {
                if (fs.existsSync(groupFilePath)) {
                    const saleData = JSON.parse(fs.readFileSync(groupFilePath));

                    if (saleData.saleActive) { // Check if sale is still active
                        fs.unlinkSync(groupFilePath); // Remove sale record

                        console.log(`Card "${cardTitle}" sale expired.`);
                        
                        // Notify users that the sale expired
                        await ctx.reply(`🟥 *The card "${cardTitle}" was not bought and the sale has ended after 5 minutes.*`);
                    }
                }
            }, 5 * 60 * 1000); // 5 minutes in milliseconds

            // Send sale message
            await ctx.reply({
                image: { url: cardToSell.url },
                caption: `🟩 *Card on Sale*\n\n🃏 *Card Name*: ${cardTitle}\n💰 *Price*: ${price} bnhz\n⭐ *Tier*: ${cardToSell.tier}\n\n⏳ This card will be on sale for *5 minutes*.\n🛒 To buy this card, type: *!buycard*\n❌ To end the sale, type: *!endsale*`
            });

        } catch (error) {
            console.error("Error selling card:", error);
            await ctx.reply("🟥 *An error occurred while attempting to sell the card.*");
        }
    }
};
