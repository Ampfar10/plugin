const admin = require("firebase-admin");
const fs = require("fs");
const path = require("path");

// Initialize Firebase
const serviceAccount = require("../../william-b3a2b-firebase-adminsdk-u5y2f-ee37853315.json");
if (!admin.apps.length) {
    admin.initializeApp({
        credential: admin.credential.cert(serviceAccount)
    });
}
const db = admin.firestore();

const sellcardsDir = path.join(__dirname, "../../sellcards");

module.exports = {
    name: "buycard",
    async execute(ctx) {
        const userId = ctx._sender?.jid;
        const groupId = ctx.id;

        if (!userId || !groupId) {
            return ctx.reply("🟥 *User or group not found.*");
        }

        try {
            const groupFilePath = path.join(sellcardsDir, `${groupId}.json`);

            // Check if a sale exists
            if (!fs.existsSync(groupFilePath)) {
                return ctx.reply("🟥 *No card is available for sale in this group.*");
            }

            // Parse sale data from file
            const saleData = JSON.parse(fs.readFileSync(groupFilePath, "utf-8"));

            if (saleData.sellerId === userId) {
                return ctx.reply("🟥 *You cannot buy your own card!*");
            }

            // If the card is locked (already purchased), prevent further buys
            if (saleData.locked) {
                return ctx.reply("🟥 *This card has already been purchased!*");
            }

            // Get buyer and seller references
            const buyerRef = db.collection("users").doc(userId);
            const sellerRef = db.collection("users").doc(saleData.sellerId);

            // Get buyer and seller documents
            const [buyerDoc, sellerDoc] = await Promise.all([buyerRef.get(), sellerRef.get()]);

            if (!buyerDoc.exists || !sellerDoc.exists) {
                return ctx.reply("🟥 *User not found.*");
            }

            const buyerData = buyerDoc.data();
            const sellerData = sellerDoc.data();

            // Check if buyer has enough money
            if (buyerData.wallet < saleData.price) {
                return ctx.reply("🟥 *You do not have enough money to buy this card.*");
            }

            // Lock the sale to prevent others from buying it
            saleData.locked = true;
            fs.writeFileSync(groupFilePath, JSON.stringify(saleData, null, 2));

            // Deduct money from buyer and add to seller
            await Promise.all([
                buyerRef.update({ wallet: buyerData.wallet - saleData.price }),
                sellerRef.update({ wallet: sellerData.wallet + saleData.price })
            ]);

            // Add card to buyer's claimed cards and remove from seller's deck
            const sellerDeck = sellerData.deck || [];
            const claimedCards = buyerData.claimedCards || [];
            const cardIndex = sellerDeck.findIndex((card) => card.title === saleData.title);

            if (cardIndex !== -1) {
                const cardToMove = sellerDeck.splice(cardIndex, 1)[0];
                claimedCards.push(cardToMove);

                await Promise.all([
                    sellerRef.update({ deck: sellerDeck }),
                    buyerRef.update({ claimedCards })
                ]);

                // Delete the sale file after purchase
                fs.unlinkSync(groupFilePath);

                // Notify the group of the successful purchase
                await ctx.reply({
                    image: { url: cardToMove.url },
                    caption: `✅ *Card successfully purchased!*\n\n🃏 *Card Name*: ${cardToMove.title}\n💰 *Price*: ${saleData.price} bnhz\n🎯 *Purchased by*: @${userId.split("@")[0]}\n\n✅ *Enjoy your new card!* 🚀`
                });
            } else {
                return ctx.reply("🟥 *Card not found in seller's deck.*");
            }

        } catch (error) {
            console.error("Error purchasing card:", error);
            await ctx.reply("🟥 *An error occurred while purchasing the card.*");
        }
    }
};
