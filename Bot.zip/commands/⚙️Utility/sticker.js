const { quote } = require("@mengkodingan/ckptw");
const { MessageType } = require("@mengkodingan/ckptw/lib/Constant");
const { Sticker, StickerTypes } = require("wa-sticker-formatter");

module.exports = {
    name: "sticker",
    handler: async (ctx) => {  // The handler function that gets executed when the command is triggered
        const status = await handler(ctx, module.exports.handler);
        if (status) return;

        const msgType = ctx.getMessageType();
        const [checkMedia, checkQuotedMedia] = await Promise.all([
            tools.general.checkMedia(msgType, ["image", "gif", "video"], ctx),
            tools.general.checkQuotedMedia(ctx.quoted, ["image", "gif", "video"])
        ]);

        if (!checkMedia && !checkQuotedMedia) {
            return await ctx.reply(quote(tools.msg.generateInstruction(["send", "reply"], ["image", "gif", "video"])));
        }

        try {
            let mediaBuffer;
            if (checkMedia) {
                mediaBuffer = await ctx.msg.media.toBuffer();
            } else if (checkQuotedMedia) {
                mediaBuffer = await ctx.quoted?.media.toBuffer();
            }

            if (!mediaBuffer) {
                return await ctx.reply(quote("❌ No valid media found."));
            }

            // Create sticker
            const sticker = new Sticker(mediaBuffer, {
                pack: 'My Sticker Pack',  // Customize pack name
                author: 'Bot Author',      // Customize author name
                type: StickerTypes.FULL,   // Full sticker type
                categories: ["🤩", "🎉"],  // Sticker categories
                id: ctx.id,
                quality: 50,               // Quality of the sticker (0-100)
            });

            // Send the sticker
            return await ctx.reply(await sticker.toMessage());

        } catch (error) {
            console.error(`Error creating sticker:`, error);
            return await ctx.reply(quote(`⚠️ Error: ${error.message}`));
        }
    }
};
