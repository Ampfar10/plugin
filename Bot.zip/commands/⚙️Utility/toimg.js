const { MessageType } = require("@mengkodingan/ckptw");
const fs = require("fs");
const path = require("path");

module.exports = {
    name: "toimg",
    description: "Convert a quoted sticker into an image.",
    async execute(ctx) {
        try {
            // Ensure the user has quoted a sticker message
            if (!(ctx.getMessageType() !== MessageType.stickerMessage && ctx.quoted?.media)) {
                return await ctx.reply("❌ Please reply to a *sticker* to convert it to an image.");
            }

            // Download the sticker as a buffer
            const buffer = await ctx.quoted.download();
            if (!buffer) {
                return await ctx.reply("❌ Failed to download the sticker. Please try again.");
            }

            // Define file path to save the image
            const filePath = path.join(__dirname, "../../downloads", `sticker-${Date.now()}.png`);
            fs.writeFileSync(filePath, buffer);

            // Send the converted image back to the user
            await ctx.reply("✅ Sticker converted to image:", { image: fs.readFileSync(filePath) });

            // Clean up: Delete the file after sending
            setTimeout(() => fs.unlinkSync(filePath), 10000); // Auto-delete after 10 sec

        } catch (error) {
            console.error("Error converting sticker:", error);
            await ctx.reply("❌ Failed to convert sticker to image.");
        }
    },
};
