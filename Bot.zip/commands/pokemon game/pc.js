const admin = require("firebase-admin");
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// Initialize Firebase
const serviceAccount = require("../../william-b3a2b-firebase-adminsdk-u5y2f-ee37853315.json");
if (!admin.apps.length) {
    admin.initializeApp({
        credential: admin.credential.cert(serviceAccount)
    });
}
const db = admin.firestore();

module.exports = {
    name: "pc",
    category: "Pokémon game",
    async execute(ctx) {
        const userId = ctx._sender?.jid;
        if (!userId) return ctx.reply("🟥 *User not found.*");

        try {
            const userDoc = await db.collection("users").doc(userId).get();
            if (!userDoc.exists) return ctx.reply("🟥 *User not found.*");

            const userData = userDoc.data();
            const caughtPokemons = userData.caughtPokemons || [];

            if (caughtPokemons.length === 0) return ctx.reply("🟥 *You have no caught Pokémon.*");

            const args = ctx.args;
            const isSortMode = args.includes("--sort");

            if (isSortMode) {
                caughtPokemons.sort((a, b) => a.name.localeCompare(b.name));
            }

            if (args.length === 1) {
                const arg = args[0];

                // Check if the argument is a number (index)
                if (!isNaN(arg)) {
                    const index = parseInt(arg, 10) - 1;
                    if (index >= 0 && index < caughtPokemons.length) {
                        const pokemon = caughtPokemons[index];

                        // Find all indexes of this Pokémon
                        const indexes = caughtPokemons
                            .map((p, i) => (p.name === pokemon.name ? i + 1 : null))
                            .filter(i => i !== null)
                            .join(", ");

                        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemon.pokemonId}`);
                        const data = await response.json();

                        const moves = data.moves.slice(0, 4).map(m => `⚡ ${m.move.name}`).join("\n");
                        const hp = data.stats.find(s => s.stat.name === "hp")?.base_stat || "Unknown";
                        const imageUrl = data.sprites.other["official-artwork"].front_default;

                        return await ctx.reply({
                            image: { url: imageUrl },
                            caption:
                                `📜 *Pokémon Details:*\n\n` +
                                `🔢 *Indexes:* ${indexes}\n` +
                                `🔠 *Name:* ${pokemon.name}\n` +
                                `💖 *HP:* ${hp}\n` +
                                `📦 *Owned:* ${indexes.split(", ").length}\n\n` +
                                `🎯 *Moves:*\n${moves}`
                        });
                    } else {
                        return ctx.reply("🟥 *Invalid Pokémon index.*");
                    }
                }

                // Check if the argument is a Pokémon name
                const nameQuery = arg.toLowerCase();
                const matchingPokemons = caughtPokemons
                    .map((p, i) => (p.name.toLowerCase() === nameQuery ? { ...p, index: i + 1 } : null))
                    .filter(p => p !== null);

                if (matchingPokemons.length > 0) {
                    const pokemon = matchingPokemons[0]; // Take first instance for details
                    const indexes = matchingPokemons.map(p => p.index).join(", ");

                    const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemon.pokemonId}`);
                    const data = await response.json();

                    const moves = data.moves.slice(0, 4).map(m => `⚡ ${m.move.name}`).join("\n");
                    const hp = data.stats.find(s => s.stat.name === "hp")?.base_stat || "Unknown";
                    const imageUrl = data.sprites.other["official-artwork"].front_default;

                    return await ctx.reply({
                        image: { url: imageUrl },
                        caption:
                            `📜 *Pokémon Details:*\n\n` +
                            `🔢 *Indexes:* ${indexes}\n` +
                            `🔠 *Name:* ${pokemon.name}\n` +
                            `💖 *HP:* ${hp}\n` +
                            `📦 *Owned:* ${matchingPokemons.length}\n\n` +
                            `🎯 *Moves:*\n${moves}`
                    });
                } else {
                    return ctx.reply("🟥 *Pokémon not found in your collection.*");
                }
            }

            // Default: Show list of Pokémon names
            let pokemonList = "📜 *Your Pokémon Collection:*\n\n";
            caughtPokemons.forEach((pokemon, index) => {
                pokemonList += `*#${index + 1} ${pokemon.name}*\n`;
            });

            const randomPokemon = caughtPokemons[Math.floor(Math.random() * caughtPokemons.length)];
            const randomPokeApiUrl = `https://pokeapi.co/api/v2/pokemon/${randomPokemon.pokemonId}`;

            try {
                const response = await fetch(randomPokeApiUrl);
                const data = await response.json();
                const imageUrl = data.sprites.other["official-artwork"].front_default;

                await ctx.reply({
                    image: { url: imageUrl },
                    caption: pokemonList
                });
            }catch (error) {
                console.error("Error fetching Pokémon image:", error);
                await ctx.reply(pokemonList);
            }

        } catch (error) {
            console.error("Error fetching or displaying Pokémon collection:", error);
            return ctx.reply("🟥 *An error occurred while retrieving your Pokémon collection.*");
        }
    }
};
