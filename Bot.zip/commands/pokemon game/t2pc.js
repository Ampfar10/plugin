const admin = require("firebase-admin");

module.exports = {
    name: "t2pc",
    async execute(ctx) {
        const userId = ctx._sender?.jid;
        if (!userId) return ctx.reply("🟥 *User not found.*");

        const args = ctx.args;
        if (args.length !== 1) return ctx.reply("🟥 *Usage: t2pc <index>*");

        const index = parseInt(args[0], 10) - 1;
        if (isNaN(index) || index < 0) return ctx.reply("🟥 *Invalid index.*");

        try {
            const userDocRef = admin.firestore().collection("users").doc(userId);
            const userDoc = await userDocRef.get();

            if (!userDoc.exists) return ctx.reply("🟥 *User not found.*");

            let userData = userDoc.data();
            let party = userData.party || [];
            let pc = userData.caughtPokemons || [];

            if (index >= party.length) return ctx.reply("🟥 *Invalid Pokémon index.*");

            // Move Pokémon from Party to PC
            const pokemon = party.splice(index, 1)[0]; // Remove from Party
            pc.push(pokemon); // Add to PC

            // Update Database
            await userDocRef.update({
                party: party,
                caughtPokemons: pc
            });

            ctx.reply(`✅ *${pokemon.name} has been returned to your PC!* 📦`);
        } catch (error) {
            console.error("Error moving Pokémon to PC:", error);
            ctx.reply("🟥 *An error occurred while moving Pokémon back to PC.*");
        }
    }
};
