const admin = require("firebase-admin");

module.exports = {
    name: "t2party",
    async execute(ctx) {
        const userId = ctx._sender?.jid;
        if (!userId) return ctx.reply("🟥 *User not found.*");

        const args = ctx.args;
        if (args.length !== 1) return ctx.reply("🟥 *Usage: t2party <index>*");

        const index = parseInt(args[0], 10) - 1;
        if (isNaN(index) || index < 0) return ctx.reply("🟥 *Invalid index.*");

        try {
            const userDocRef = admin.firestore().collection("users").doc(userId);
            const userDoc = await userDocRef.get();

            if (!userDoc.exists) return ctx.reply("🟥 *User not found.*");

            let userData = userDoc.data();
            let pc = userData.caughtPokemons || [];
            let party = userData.party || [];

            if (index >= pc.length) return ctx.reply("🟥 *Invalid Pokémon index.*");
            if (party.length >= 6) return ctx.reply("🟥 *Your party is full (6 Pokémon max).*");

            // Move Pokémon from PC to Party
            const pokemon = pc.splice(index, 1)[0]; // Remove from PC
            party.push(pokemon); // Add to Party

            // Update Database
            await userDocRef.update({
                caughtPokemons: pc,
                party: party
            });

            ctx.reply(`✅ *${pokemon.name} has been added to your party!* 🎉`);
        } catch (error) {
            console.error("Error moving Pokémon to party:", error);
            ctx.reply("🟥 *An error occurred while adding Pokémon to your party.*");
        }
    }
};
