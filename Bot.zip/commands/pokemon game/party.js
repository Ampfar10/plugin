const admin = require("firebase-admin");
const Jimp = require("jimp");
const fs = require("fs");
const path = require("path");
const fetch = (...args) => import("node-fetch").then(({ default: fetch }) => fetch(...args));

module.exports = {
    name: "party",
    category: "Pokémon game",
    async execute(ctx) {
        const userId = ctx._sender?.jid;
        if (!userId) return ctx.reply("🟥 *User not found.*");

        try {
            const userRef = admin.firestore().collection("users").doc(userId);
            const userDoc = await userRef.get();

            if (!userDoc.exists) return ctx.reply("🟥 *User not found.*");

            const userData = userDoc.data();
            const party = userData.party || [];

            if (party.length === 0) return ctx.reply("🟥 *Your party is empty.*");

            // Ensure downloads directory exists
            const downloadsDir = path.join(__dirname, "../../downloads");
            if (!fs.existsSync(downloadsDir)) {
                fs.mkdirSync(downloadsDir);
            }

            // Fetch Pokémon images
            const images = await Promise.all(
                party.map(async (pokemon) => {
                    try {
                        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemon.pokemonId}`);
                        const data = await response.json();
                        const imageUrl = data.sprites.other["official-artwork"].front_default;

                        if (!imageUrl) throw new Error(`No image found for ${pokemon.name}`);

                        const imgBuffer = await fetch(imageUrl).then(res => res.buffer());
                        return await Jimp.read(imgBuffer);
                    } catch (error) {
                        console.error(`Error loading image for ${pokemon.name}:`, error);
                        return null;
                    }
                })
            );

            const validImages = images.filter(img => img !== null);
            if (validImages.length === 0) return ctx.reply("🟥 *Failed to load party images.*");

            // Set dimensions
            const cardWidth = validImages[0].bitmap.width;
            const cardHeight = validImages[0].bitmap.height;
            const padding = 20;

            // Grid layout (max 3 per row)
            const cols = Math.min(validImages.length, 3);
            const rows = Math.ceil(validImages.length / cols);
            const totalWidth = cols * (cardWidth + padding) - padding;
            const totalHeight = rows * (cardHeight + padding) - padding;

            // Create blank white canvas
            const combinedImage = new Jimp(totalWidth, totalHeight, 0xffffffff);

            // Place each Pokémon in the grid
            validImages.forEach((img, index) => {
                const x = (index % cols) * (cardWidth + padding);
                const y = Math.floor(index / cols) * (cardHeight + padding);
                combinedImage.composite(img, x, y);
            });

            // Save final merged image
            const outputFilePath = path.join(downloadsDir, `party_${userId}.jpg`);
            await combinedImage.writeAsync(outputFilePath);

            // Create party info text
            let partyList = "🎉 *Your Pokémon Party:*\n\n";
            
            party.forEach((pokemon, index) => {

                partyList += `*#${index + 1} ${pokemon.name}*\n❤️ HP: ${pokemon.hp}\n⭐ Level: ${pokemon.level}\n`;
            });

            // Send the party list with the combined image
            await ctx.reply({
                image: { url: outputFilePath },
                caption: partyList
            });

        } catch (error) {
            console.error("Error generating party image:", error);
            await ctx.reply("🟥 *An error occurred while retrieving your party.*");
        }
    }
};
