const admin = require("firebase-admin");

module.exports = {
    name: "give-pokemon",
    category: "Pokémon game",
    async execute(ctx) {
        const senderId = ctx._sender?.jid;
        const args = ctx.args;

        if (!senderId) {
            return ctx.reply("🟥 *User not found.*");
        }

        if (args.length < 2) {
            return ctx.reply("🟥 *Usage:* give-pokemon <party index> @user");
        }

        // Get the index of the Pokémon
        const partyIndex = parseInt(args[0], 10) - 1;
        if (isNaN(partyIndex) || partyIndex < 0) {
            return ctx.reply("🟥 *Invalid Pokémon index.*");
        }

        // Determine recipient ID (tagged user or quoted message user)
        const mentionedJid = ctx.quoted?.sender || (ctx.mentionedJid?.[0] || "").replace(/:[0-9]+/g, "");
        if (!mentionedJid) {
            return ctx.reply("🟥 *You must tag or quote a user to give the Pokémon.*");
        }

        if (mentionedJid === senderId) {
            return ctx.reply("🟥 *You cannot give a Pokémon to yourself.*");
        }

        try {
            const senderDoc = await admin.firestore().collection("users").doc(senderId).get();
            if (!senderDoc.exists) {
                return ctx.reply("🟥 *You do not have any Pokémon.*");
            }

            const senderData = senderDoc.data();
            let senderParty = senderData.party || [];

            if (partyIndex >= senderParty.length) {
                return ctx.reply("🟥 *Invalid Pokémon index.*");
            }

            // Get the Pokémon from the sender's party
            const givenPokemon = senderParty[partyIndex];

            // Remove Pokémon from sender's party
            senderParty.splice(partyIndex, 1);
            await admin.firestore().collection("users").doc(senderId).update({
                party: senderParty
            });

            // Add Pokémon to recipient's PC
            const recipientDoc = await admin.firestore().collection("users").doc(mentionedJid).get();
            let recipientPC = recipientDoc.exists ? recipientDoc.data().caughtPokemons || [] : [];
            recipientPC.push(givenPokemon);

            await admin.firestore().collection("users").doc(mentionedJid).set(
                { caughtPokemons: recipientPC },
                { merge: true }
            );

            return ctx.reply(`✅ *You have given ${givenPokemon.name} to the recipient!* 🎁`);
        } catch (error) {
            console.error("Error giving Pokémon:", error);
            return ctx.reply("🟥 *An error occurred while transferring the Pokémon.*");
        }
    }
};
