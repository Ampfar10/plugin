const { Client, Events, Ctx} = require("@mengkodingan/ckptw");
const fs = require("fs");
const path = require("path");

// Initialize bot
const bot = new Client({
    WAVersion: [2, 3000, 1015901307],
    prefix: "!",
    printQRInTerminal: true,
    phoneNumber: "27774024472",
    readIncommingMsg: false,
});

module.exports = bot; 

bot.ev.on(Events.Message, (message) => {
    const senderName = message.senderName || "Unknown";
    const chatId = message.chatId;
    const messageContent = message.text || "No message content"; 
    console.log(`Received message: "${messageContent}" in: ${chatId} from: ${senderName}`);
});



// Recursive function to load commands and group by category
const commandsByCategory = {};
function loadCommands(directory, category = "Uncategorized") {
    const files = fs.readdirSync(directory);

    files.forEach((file) => {
        const fullPath = path.join(directory, file);

        if (fs.statSync(fullPath).isDirectory()) {
            // If it's a folder, use the folder name as the category
            loadCommands(fullPath, file);
        } else if (file.endsWith(".js")) {
            const command = require(fullPath);
            if (!commandsByCategory[category]) {
                commandsByCategory[category] = [];
            }
            commandsByCategory[category].push(command);

            // Register the command with the bot
            bot.command(command.name, async (ctx, args) => {
                try {
                    ctx.bot = bot;
                    await command.execute(ctx, commandsByCategory, args);
                } catch (error) {
                    console.error(`Error executing command "${command.name}":`, error);
                    await ctx.reply("❌ An error occurred while executing the command.");
                }
            });
        }
    });
}

// Load all commands from the 'commands' folder
loadCommands(path.join(__dirname, "commands"));

bot.ev.on(Events.MessageCreate, async (ctx) => {
    try {
        if (!ctx.body.startsWith(bot.prefix)) return; // Ignore messages without the prefix
        await handleMessage(ctx, commandsByCategory, bot);
    } catch (error) {
        console.error("Error handling message:", error);
        await ctx.reply("❌ An error occurred while processing your message.");
    }
});

bot.ev.once(Events.ClientReady, (m) => {
    console.log(`Bot is ready: ${m.user.id}`);
});

bot.ev.on(Events.GroupParticipantsUpdate, async (update) => {
    const { id, participants, action } = update;

    participants.forEach(async (participant) => {
        let message;

        if (action === "promote") {
            message = `🎉 @${participant.split("@")[0]} has been promoted `;
        } else if (action === "demote") {
            message = `⚠️ @${participant.split("@")[0]} has been demoted`;
        }

        if (message) {
            await bot.sendMessage(id, { text: message, mentions: [participant] });
        }
    });
});


// Launch bot
bot.launch();
