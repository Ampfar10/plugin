module.exports = {
    async handleMessage(ctx, commandsByCategory) {
        const commandName = ctx.body.slice(ctx.prefix.length).split(" ")[0].toLowerCase();
        const args = ctx.body.slice(ctx.prefix.length + commandName.length).trim().split(/\s+/);

        let found = false;

        for (const category in commandsByCategory) {
            for (const command of commandsByCategory[category]) {
                if (command.name === commandName) {
                    found = true;
                    try {
                        await command.execute(ctx, commandsByCategory, args);
                    } catch (error) {
                        console.error(`Error executing command "${command.name}":`, error);
                        await ctx.reply("❌ An error occurred while executing the command.");
                    }
                    break;
                }
            }
            if (found) break;
        }

        if (!found) {
            await ctx.reply("❓ Command not recognized. Use `!help` to see all available commands.");
        }
    },
};
